insert into TODO(id,task,status,date)  values(1,'This is pending',false,'10-10-2022');
insert into TODO(id,task,status,date)  values(2,'This is pending',false,'10-10-2022');
insert into TODO(id,task,status,date)  values(3,'This is pending',false,'10-10-2022');
insert into TODO(id,task,status,date)  values(4,'This is pending',false,'10-10-2022');
insert into TODO(id,task,status,date)  values(5,'This is pending',false,'10-10-2022');
insert into TODO(id,task,status,date)  values(6,'This is pending',false,'10-10-2022');